﻿using System;

public class Konyv
{

    private int id;
    private string szerzo;
    private string cim;
    private string kiad;
    private string kiado;
    private bool kolcsonozheto;

    public int konyvId
    {
        get { return id; }
        set { id = value; }
    }

    public string konyszerzo
    {
        get { return szerzo; }
        set { szerzo = value; }
    }

    public string konycim
    {
        get { return cim; }
        set { cim = value; }
    }

    public string konykiad
    {
        get { return kiad; }
        set { kiad = value; }
    }

    public string konykiado
    {
        get { return kiado; }
        set { kiado = value; }
    }

    public bool konykolcsonozheto
    {
        get { return kolcsonozheto; }
        set { kolcsonozheto = value; }
    }

    public Konyv(string asd)
    {
       
        string[] resz = asd.Split(';');
        id = int.Parse(resz[0]);
        szerzo = resz[1];
        cim = resz[2];
        kiad = resz[3];
        kiado = resz[4];
        kolcsonozheto = bool.Parse(resz[5]);
        
       
    }

    public Konyv(int id, string szerzor, string cim, string kiad, string kiado, bool kolcsonozheto)
    {
        this.id = id;
        this.szerzo = szerzor;
        this.cim = cim;
        this.kiad = kiad;
        this.kiado = kiado;
        this.kolcsonozheto = kolcsonozheto;
    }

}

