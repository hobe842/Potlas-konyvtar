﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Könyvtár
{
    class Szemely
    {
        private int id;
        private string nev;
        private string szul;
        private int iranysz;
        private string varos;
        private string utca;

        public int szemeyid
        {
            get { return id; }
            set { id = value; }
        }
        public string szemelynev
        {
            get { return nev; }
            set { nev = value; }
        }
        public string szemelyszul
        {
            get { return szul; }
            set { szul = value; }
        }
        public int szemelyiranysz
        {
            get { return iranysz; }
            set { iranysz = value; }
        }
        public string szemelyvaros
        {
            get { return varos; }
            set { varos = value; }
        }
        public string szemelyutca
        {
            get { return utca; }
            set { utca = value; }
        }

        public Szemely(string asd)
        {
            string[] resz = asd.Split(';');
            id = int.Parse(resz[0]);
            nev = resz[1];
            szul = resz[2];
            iranysz = int.Parse(resz[3]);
            varos = resz[4];
            utca = resz[5];
        }

        public Szemely(int id, string nev, string szul, int iranysz, string varos, string utca)
        {
            this.id = id;
            this.nev = nev;
            this.szul = szul;
            this.iranysz = iranysz;
            this.varos = varos;
            this.utca = utca;
        }
    }
}
