﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Könyvtár
{
    class Kolcsonz
    {
        private int id;
        private int szemelyid;
        private int konyvid;
        private DateTime kolcsonnap;
        private DateTime kolcsonveg;

        public int kolcsonzid
        {
            get { return id; }
            set { id = value; }
        }

        public int kolcsonzszemelyid
        {
            get { return szemelyid; }
            set { szemelyid = value; }
        }

        public int kolcsonzkonyvid
        {
            get { return konyvid; }
            set { konyvid = value; }
        }

        public DateTime kolcsonznap
        {
            get { return kolcsonnap; }
            set { kolcsonnap = value; }
        }

        public DateTime kolcsonzvegnap
        {
            get { return kolcsonveg; }
            set { kolcsonveg = value; }
        }

        public Kolcsonz(string asd)
        {
            string[] resz = asd.Split(';');
            this.id = int.Parse(resz[0]);
            this.szemelyid = int.Parse(resz[1]);
            this.konyvid = int.Parse(resz[2]);
            this.kolcsonnap = DateTime.Parse(resz[3]);
            this.kolcsonveg = DateTime.Parse(resz[4]);
        }

        public Kolcsonz(int id, int szemelyid, int konyvid, DateTime kolcsonznap, int kolcsonzido)
        {
            this.id = id;
            this.szemelyid = szemelyid;
            this.konyvid = konyvid;
            this.kolcsonnap = kolcsonznap;
            this.kolcsonveg = kolcsonznap;
            this.kolcsonveg = kolcsonveg.AddDays(kolcsonzido);
        }
    }
}
