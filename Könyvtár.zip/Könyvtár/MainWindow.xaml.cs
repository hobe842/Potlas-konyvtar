﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Könyvtár
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IList<Konyv> konyvek = new List<Konyv>();
        IList<Szemely> tagok = new List<Szemely>();
        IList<Kolcsonz> kolcsonzesek = new List<Kolcsonz>();
        IList<Kolcsonz> lejartkol = new List<Kolcsonz>();
        IList<Kolcsonz> szemelykolcs = new List<Kolcsonz>();

        string mentéshelye = AppDomain.CurrentDomain.BaseDirectory;
        public MainWindow()
        {
            InitializeComponent();
            Init();
        }

        public void Init()
        {
            konyvekdg.ItemsSource = konyvek;
            konyvekdg.AutoGenerateColumns = false;
            tagokdg.ItemsSource = tagok;
            tagokdg.AutoGenerateColumns = false;
            kolcsonzesekdg.ItemsSource = kolcsonzesek;
            kolcsonzesekdg.AutoGenerateColumns = false;
            lejartkolcsdg.ItemsSource = lejartkol;
            lejartkolcsdg.AutoGenerateColumns = false;
            taglajartdg.ItemsSource = szemelykolcs;
            taglajartdg.AutoGenerateColumns = false;

            StreamReader srk = new StreamReader("konyvek.txt");
            while (true)
            {
                string sor = srk.ReadLine();
                if (sor==null)
                {
                    break;
                }
                konyvek.Add(new Konyv(sor));
            }

            StreamReader srsz = new StreamReader("tagok.txt");
            while (true)
            {
                string sor = srsz.ReadLine();
                if (sor == null)
                {
                    break;
                }
                tagok.Add(new Szemely(sor));
            }

            StreamReader srkolcs = new StreamReader("kolcsonzesek.txt");
            while (true)
            {
                string sor = srkolcs.ReadLine();
                if (sor == null)
                {
                    break;
                }
                kolcsonzesek.Add(new Kolcsonz(sor));
            }

            StreamReader srlejart = new StreamReader("lejart.txt");
            while (true)
            {
                string sor = srk.ReadLine();
                if (sor == null)
                {
                    break;
                }
                lejartkol.Add(new Kolcsonz(sor));
            }

            Lejartkolcsonz();
        }

        private void Lejartkolcsonz()
        {
            foreach (var item in kolcsonzesek.ToList())
            {
                if (item.kolcsonzvegnap < DateTime.Today)
                {
                    lejartkol.Add(item);
                    kolcsonzesek.Remove(item);
                }
            }
        }

        private void Konyvkeres(object sender, TextChangedEventArgs e)
        {
            ComboBoxItem selected = (ComboBoxItem)bookSearchTypeCb.SelectedItem;
            if (konyvkerestb.Text == "")
                konyvekdg.ItemsSource = konyvek;
            else if (selected.Content.ToString() == "Szerző")
                konyvekdg.ItemsSource = konyvek.Where(x => x.konyszerzo.Contains(konyvkerestb.Text));
            else if (selected.Content.ToString() == "Cím")
                konyvekdg.ItemsSource = konyvek.Where(x => x.konycim.Contains(konyvkerestb.Text));
            else if (selected.Content.ToString() == "Kiadási év")
                konyvekdg.ItemsSource = konyvek.Where(x => x.konykiad.Contains(konyvkerestb.Text));
            else
                konyvekdg.ItemsSource = konyvek.Where(x => x.konykiado.Contains(konyvkerestb.Text));
        }

        private void Tagkeres(object sender, TextChangedEventArgs e)
        {
            ComboBoxItem selected = (ComboBoxItem)memberSearchTypeCb.SelectedItem;
            if (tagkerestb.Text == "")
                tagokdg.ItemsSource = tagok;
            else if (selected.Content.ToString() == "Név")
                tagokdg.ItemsSource = tagok.Where(x => x.szemelynev.Contains(tagkerestb.Text));
            else if (selected.Content.ToString() == "Születésnap")
                tagokdg.ItemsSource = tagok.Where(x => x.szemelyszul.Contains(tagkerestb.Text));
            else if (selected.Content.ToString() == "Település")
                tagokdg.ItemsSource = tagok.Where(x => x.szemelyvaros.Contains(tagkerestb.Text));
            else
                tagokdg.ItemsSource = tagok.Where(x => x.szemelyutca.Contains(tagkerestb.Text));
        }

        private void Konyvvalaszt(object sender, SelectionChangedEventArgs e)
        {
            Konyv selected = (Konyv)konyvekdg.SelectedItem;
            if (selected != null)
            {
                kolcsonozcb.IsChecked = selected.konykolcsonozheto;
                konyvszerzotb.Text = selected.konyszerzo;
                konvcimtb.Text = selected.konycim;
                konyvkolcstb.Text = selected.konykiad;
                konyvkiadotb.Text = selected.konykiado;
                kolcsonkonyvtb.Text = selected.konyvId.ToString();
            }
        }

        private void Konyvmentes(object sender, RoutedEventArgs e)
        {
            Konyv selected = (Konyv)konyvekdg.SelectedItem;
            try
            {
                if (selected != null)
                {
                    selected.konykolcsonozheto = (bool)kolcsonozcb.IsChecked;
                    selected.konyszerzo = konyvszerzotb.Text;
                    selected.konycim = konvcimtb.Text;
                    selected.konykiad = konyvkolcstb.Text;
                    selected.konykiado = konyvkiadotb.Text;
                    konyvekdg.Items.Refresh();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba az adatok mentésében");
            }
        }

        private void Tagvalaszt(object sender, SelectionChangedEventArgs e)
        {
            Szemely selected = (Szemely)tagokdg.SelectedItem;
            if (selected != null)
            {
                szemelykolcs.Clear();
                tagnevtb.Text = selected.szemelynev;
                tagszultb.Text = selected.szemelyszul;
                tagiranysz.Text = selected.szemelyiranysz.ToString();
                tagvarostb.Text = selected.szemelyvaros;
                tagutcatb.Text = selected.szemelyutca;
                var tmp = kolcsonzesek.Where(x => x.kolcsonzszemelyid == selected.szemeyid);
                foreach (var item in tmp)
                {
                    szemelykolcs.Add(item);
                }
                taglajartdg.Items.Refresh();
            }
        }

        private void Tagmentes(object sender, RoutedEventArgs e)
        {
            Szemely selected = (Szemely)tagokdg.SelectedItem;
            try
            {
                if (selected != null)
                {
                    selected.szemelynev = tagnevtb.Text;
                    selected.szemelyszul = tagszultb.Text;
                    selected.szemelyiranysz= int.Parse(tagiranysz.Text);
                    selected.szemelyvaros = tagvarostb.Text;
                    selected.szemelyutca = tagutcatb.Text;
                    tagokdg.Items.Refresh();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba az adatok mentésében");
            }
        }

        private void Konyvtorles(object sender, RoutedEventArgs e)
        {
            Konyv selected = (Konyv)konyvekdg.SelectedItem;
            konyvek.Remove(selected);
            konyvekdg.SelectedItem = null;
            konyvekdg.Items.Refresh();
        }

        private void Tatorles(object sender, RoutedEventArgs e)
        {
            Szemely selected = (Szemely)tagokdg.SelectedItem;
            tagok.Remove(selected);
            tagokdg.SelectedItem = null;
            tagokdg.Items.Refresh();
        }

        private void Konyvadd(object sender, RoutedEventArgs e)
        {
            try
            {
                konyvek.Add(new Konyv(konyvek.Count + 1, konyvszerzotb.Text, konvcimtb.Text, konyvkolcstb.Text, konyvkiadotb.Text, (bool)kolcsonozcb.IsChecked));
                konyvekdg.Items.Refresh();
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba tortent.");
            }

        }
        private void Tagadd(object sender, RoutedEventArgs e)
        {
            try
            {
                tagok.Add(new Szemely(tagok.Count + 1, tagnevtb.Text, tagszultb.Text, int.Parse(tagiranysz.Text), tagvarostb.Text, tagutcatb.Text));
                tagokdg.Items.Refresh();
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba tortent.");
            }

        }

        private void Kolcsonzesadd(object sender, RoutedEventArgs e)
        {
            try
            {
                if (konyvek.Where(x => x.konyvId == int.Parse(kolcsonkonyvtb.Text) && x.konykolcsonozheto == true).Any())
                {
                    kolcsonzesek.Add(new Kolcsonz(kolcsonzesek.Count + 1, int.Parse(kolcsontagtb.Text), int.Parse(kolcsonkonyvtb.Text), DateTime.Today, int.Parse(kolcsonidotb.Text)));
                    var selected = konyvek.Where(x => x.konyvId == int.Parse(kolcsonkonyvtb.Text));
                    foreach (var item in selected)
                    {
                        item.konykolcsonozheto = false;
                    }
                    konyvekdg.Items.Refresh();
                    kolcsonzesekdg.Items.Refresh();
                }
                else
                {
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba tortent.");
            }

        }
        private void Kolcsonzestorles(object sender, RoutedEventArgs e)
        {
            Kolcsonz selected = (Kolcsonz)kolcsonzesekdg.SelectedItem;
            if (selected != null)
            {
                int selectedBookId = selected.kolcsonzkonyvid;
                var tmp = konyvek.Where(x => x.konyvId == selectedBookId);
                foreach (var item in tmp)
                {
                    item.konykolcsonozheto = true;
                }
                kolcsonzesek.Remove(selected);
                kolcsonzesekdg.SelectedItem = null;
                kolcsonzesekdg.Items.Refresh();
                konyvekdg.Items.Refresh();
            }
        }

        private void Lejartkolcsonzestorles(object sender, RoutedEventArgs e)
        {
            Kolcsonz selected = (Kolcsonz)lejartkolcsdg.SelectedItem;
            if (selected != null)
            {
                int selectedBookId = selected.kolcsonzkonyvid;
                var tmp = konyvek.Where(x => x.konyvId == selectedBookId);
                foreach (var item in tmp)
                {
                    item.konykolcsonozheto = true;
                }
                lejartkol.Remove(selected);
                lejartkolcsdg.SelectedItem = null;
                lejartkolcsdg.Items.Refresh();
                konyvekdg.Items.Refresh();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            System.Windows.Forms.FolderBrowserDialog fd = new System.Windows.Forms.FolderBrowserDialog();
            fd.ShowDialog();
            ment.Text = fd.SelectedPath;
            mentéshelye = fd.SelectedPath;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            StreamWriter swk = new StreamWriter($"{mentéshelye}/konyvek.txt");
            foreach (var item in konyvek)
            {
                swk.WriteLine($"{item.konyvId};{item.konyszerzo};{item.konycim};{item.konykiad};{item.konykiado};{item.konykolcsonozheto}");

            }
            swk.Close();

            StreamWriter swt = new StreamWriter($"{mentéshelye}/tagok.txt");
            foreach (var item in tagok)
            {
                swt.WriteLine($"{item.szemeyid};{item.szemelynev};{item.szemelyszul};{item.szemelyiranysz};{item.szemelyvaros};{item.szemelyutca}");

            }
            swt.Close();

            StreamWriter swkolcs = new StreamWriter($"{mentéshelye}/kolcsonzesek.txt");
            foreach (var item in kolcsonzesek)
            {
                swkolcs.WriteLine($"{item.kolcsonzid};{item.kolcsonzkonyvid};{item.kolcsonzszemelyid};{item.kolcsonznap};{item.kolcsonzvegnap}");

            }
            swkolcs.Close();

            StreamWriter swlejart = new StreamWriter($"{mentéshelye}/lejart.txt");
            foreach (var item in lejartkol)
            {
                swlejart.WriteLine($"{item.kolcsonzid};{item.kolcsonzkonyvid};{item.kolcsonzszemelyid};{item.kolcsonznap};{item.kolcsonzvegnap}");

            }
            swlejart.Close();

        }
    }
}
